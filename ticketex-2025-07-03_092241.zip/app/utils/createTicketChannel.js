const fs = require("fs");
const path = require("path");
const {
  ChannelType,
  PermissionsBitField,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle
} = require("discord.js");
const { startTicketTimer } = require("../functions/ticketTimerManager"); // ⏱️ Süre fonksiyonunu ekle

async function createTicketChannel(client, interaction, kategori) {
  const config = client.config;
  const guild = interaction.guild;
  const member = interaction.member;

  let parentId = config.ticketParentCategoryID;

  // 🔧 Kategori yoksa oluştur
  if (!parentId) {
    const parent = await guild.channels.create({
      name: "🎫 Ticketlar",
      type: ChannelType.GuildCategory
    });

    parentId = parent.id;
    config.ticketParentCategoryID = parentId;

    const configPath = path.join(__dirname, "../config.json");
    fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
  }

  // ❌ Aynı kişi zaten ticket açtıysa uyar
  const mevcutTicket = guild.channels.cache.find(
    c =>
      c.type === ChannelType.GuildText &&
      c.parentId === parentId &&
      c.topic === member.id
  );

  if (mevcutTicket) {
    return interaction.editReply({
      content: `❌ Zaten açık bir ticket'in var: ${mevcutTicket}`,
      ephemeral: true
    });
  }

  // Kanal adı
  const kanalAdı = config.ticketChannelName
    .replace("{kullanici}", member.user.username.toLowerCase().replace(/[^a-z0-9]/g, ""));

  // 📺 Kanal oluştur
  const ticketChannel = await guild.channels.create({
    name: kanalAdı,
    type: ChannelType.GuildText,
    parent: parentId,
    topic: member.id,
    permissionOverwrites: [
      {
        id: guild.roles.everyone.id,
        deny: [PermissionsBitField.Flags.ViewChannel]
      },
      {
        id: member.id,
        allow: [
          PermissionsBitField.Flags.ViewChannel,
          PermissionsBitField.Flags.SendMessages,
          PermissionsBitField.Flags.ReadMessageHistory
        ]
      },
      {
        id: config.ticketStaffRoleID,
        allow: [
          PermissionsBitField.Flags.ViewChannel,
          PermissionsBitField.Flags.SendMessages,
          PermissionsBitField.Flags.ReadMessageHistory,
          PermissionsBitField.Flags.ManageMessages
        ]
      }
    ]
  });

  // 🔘 Butonlar
  const buttonUser = new ButtonBuilder()
    .setCustomId("ticket_kapat_user")
    .setLabel("Kapat (Kullanıcı)")
    .setStyle(ButtonStyle.Secondary);

  const buttonStaff = new ButtonBuilder()
    .setCustomId("ticket_kapat_staff")
    .setLabel("Kapat (Yetkili)")
    .setStyle(ButtonStyle.Danger);

  const buttonDevral = new ButtonBuilder()
    .setCustomId("ticket_devral")
    .setLabel("Devral")
    .setStyle(ButtonStyle.Primary);

  const row = new ActionRowBuilder().addComponents(buttonUser, buttonStaff, buttonDevral);

  // Embed mesaj
  const embed = new EmbedBuilder()
    .setColor("Blue")
    .setTitle("🎫 Destek Talebi")
    .setDescription(`Kategori: **${kategori}**\nYetkililer en kısa sürede sizinle ilgilenecek.\n\nTicketi kapatmak veya devralmak için aşağıdaki butonları kullanabilirsiniz.`)
    .setFooter({ text: `${client.user.username} • Ticket Sistemi` })
    .setTimestamp();

  await ticketChannel.send({
    content: `<@${member.id}> | <@&${config.ticketStaffRoleID}>`,
    embeds: [embed],
    components: [row]
  });

  // 🕒 TICKET SÜRE SİSTEMİ BAŞLAT ⬇
  startTicketTimer(ticketChannel.id, client); // ⏱️ Otomatik süre başlat

  // 🗃️ JSON’a kaydet
  const dataPath = path.join(__dirname, "../veri/ticketKullanicilar.json");
  let liste = [];

  try {
    liste = JSON.parse(fs.readFileSync(dataPath, "utf8"));
  } catch {
    liste = [];
  }

  const userId = interaction.user.id;
  if (!liste.includes(userId)) {
    liste.push(userId);
    fs.writeFileSync(dataPath, JSON.stringify(liste, null, 2));
  }

  await interaction.editReply({
    content: `✅ Ticket oluşturuldu: ${ticketChannel}`,
    ephemeral: true
  });
}

module.exports = { createTicketChannel };
