// ─── POLYFILL: web-streams-polyfill ────────────────────────────────────────────
const streams = require("web-streams-polyfill/ponyfill");
global.ReadableStream  = global.ReadableStream  || streams.ReadableStream;
global.WritableStream  = global.WritableStream  || streams.WritableStream;
global.TransformStream = global.TransformStream || streams.TransformStream;

// ─── GEREKLİ IMPORTLAR ─────────────────────────────────────────────────────────
const { Client, GatewayIntentBits, Collection, Partials } = require("discord.js");
const fs = require("fs");
const path = require("path");
const config = require("./config.json");
const express = require("express");
const cron = require("node-cron");
const ticketDailyReport = require("./jobs/ticketDailyReport");

const app = express();

// ─── PING & ANASAYFA ────────────────────────────────────────────────────────────
app.get("/ping", (req, res) => {
  res.status(200).send("✅ Glitch Projesi Aktif - " + new Date().toLocaleString());
});

app.get("/", (req, res) => {
  res.send("Hoş geldin, Glitch projen çalışıyor.");
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🌐 Sunucu port ${PORT} üzerinde çalışıyor`);
});

// ─── DISCORD CLIENT OLUŞTUR ─────────────────────────────────────────────────────
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessages
  ],
  partials: [Partials.Channel]
});

client.commands = new Collection();
client.config = config;

// ─── KOMUTLARI YÜKLE ────────────────────────────────────────────────────────────
fs.readdirSync(path.join(__dirname, "commands"))
  .filter(file => file.endsWith(".js"))
  .forEach(file => {
    const cmd = require(`./commands/${file}`);
    client.commands.set(cmd.name, cmd);
  });

// ─── EVENTLERİ YÜKLE ────────────────────────────────────────────────────────────
fs.readdirSync(path.join(__dirname, "events"))
  .filter(file => file.endsWith(".js"))
  .forEach(file => {
    const evt = require(`./events/${file}`);
    client.on(evt.name, (...args) => evt.run(client, ...args));
  });

// ─── GÜNLÜK RAPOR CRON (Her gece 23:59) ────────────────────────────────────────
cron.schedule("59 23 * * *", () => {
  ticketDailyReport(client);
});


const { joinVoiceChannel } = require('@discordjs/voice');

client.on("ready", () => {
  const channel = client.channels.cache.get("1389274245615325316"); // ses kanalı ID'si
  if (!channel || channel.type !== 2) return console.log("❌ Ses kanalı bulunamadı.");

  joinVoiceChannel({
    channelId: channel.id,
    guildId: channel.guild.id,
    adapterCreator: channel.guild.voiceAdapterCreator,
    selfDeaf: false // mikrofona erişim açık olsun istiyorsan false bırak
  });

  console.log("✅ Bot başarıyla ses kanalına katıldı.");
});

// ─── BOT GİRİŞİ ────────────────────────────────────────────────────────────────
client.login(config.token).then(() => {
  // Bot giriş yaptıktan sonra günlük raporu başlat
  ticketDailyReport(client);
}).catch(err => {
  console.error("❌ Bot giriş hatası:", err);
});

// ─── BEKLENMEYEN HATALARI YAKALA ───────────────────────────────────────────────
process.on("unhandledRejection", error => {
  console.error("❗ Unhandled promise rejection:", error);
});
