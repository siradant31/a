const timers = new Map();

function startTicketTimer(channelId, client) {
  // Zaten aktif bir timer varsa sil
  if (timers.has(channelId)) clearTimeout(timers.get(channelId));

  const timer = setTimeout(async () => {
    const channel = client.channels.cache.get(channelId);
    if (!channel) return;

    try {
      // Son 2 dakika içinde yetkili yazdı mı kontrol et
      const fetched = await channel.messages.fetch({ limit: 50 });
      const now = Date.now();

      const recentlyStaffMessage = fetched.some(msg => {
        const isStaff = msg.member?.roles.cache.has(client.config.ticketStaffRoleID);
        const sentInLast2Min = now - msg.createdTimestamp <= 2 * 60 * 1000;
        return isStaff && sentInLast2Min;
      });

      if (!recentlyStaffMessage) {
        await channel.send({
          content: "⚠️ 2 dakikadır yetkililerden yanıt gelmedi. Lütfen sabırlı olun, en kısa sürede ilgileneceklerdir."
        });
      }

      timers.delete(channelId);
    } catch (err) {
      console.error("Ticket zamanlayıcı hatası:", err);
    }

  }, 1 * 60 * 1000); // 2 dakika

  timers.set(channelId, timer);
}

function handleTicketMessage(channelId) {
  if (timers.has(channelId)) {
    clearTimeout(timers.get(channelId));
    timers.delete(channelId);
  }
}

module.exports = {
  startTicketTimer,
  handleTicketMessage
};
