const config = require("../config.json");

function isBotOwner(message) {
  return message.author.id === config.botOwnerID; // botOwnerID config.json içinde olmalı
}

function isServerOwner(message) {
  return message.author.id === message.guild?.ownerId;
}

function isAdmin(message) {
  if (!message.guild) return false;

  // Bot sahibi veya sunucu sahibi ise
  if (isBotOwner(message) || isServerOwner(message)) return true;

  // Kullanıcının yönetici yetkisi var mı?
  return message.member.permissions.has("Administrator");
}

module.exports = {
  isBotOwner,
  isServerOwner,
  isAdmin
};
