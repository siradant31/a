const {
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  EmbedBuilder
} = require("discord.js");
const fs = require("fs");
const path = require("path");
const { createTicketChannel } = require("../utils/createTicketChannel");

const logPath = path.join(__dirname, "../veri/ticket_log.json");

module.exports = {
  name: "interactionCreate",
  run: async (client, interaction) => {
    if (interaction.isStringSelectMenu() && interaction.customId === "ticket_kategori_sec") {
      const kategori = interaction.values[0];
      if (kategori === "reset") {
        return interaction.reply({
          content: "🔄 Seçim sıfırlandı. Lütfen tekrar bir kategori seçin.",
          ephemeral: true
        });
      }

      try {
        await interaction.deferReply({ ephemeral: true });
        await createTicketChannel(client, interaction, kategori);
      } catch (err) {
        console.error("🎫 Ticket oluşturma hatası:", err);
        return interaction.editReply({
          content: "❌ Ticket oluşturulurken bir hata oluştu.",
          ephemeral: true
        });
      }
    }

    if (
      interaction.isButton() &&
      (interaction.customId === "ticket_kapat_user" || interaction.customId === "ticket_kapat_staff")
    ) {
      if (interaction.customId === "ticket_kapat_staff") {
        const staffRoleId = client.config.ticketStaffRoleID;
        if (!interaction.member.roles.cache.has(staffRoleId)) {
          return interaction.reply({
            content: "❌ Bu butonu sadece **yetkili** rolüne sahip kişiler kullanabilir.",
            ephemeral: true
          });
        }
      }

      const modal = new ModalBuilder()
        .setCustomId("ticket_kapat_modal")
        .setTitle("Ticket Kapatma Sebebi")
        .addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder()
              .setCustomId("sebep")
              .setLabel("Ticket neden kapatılıyor?")
              .setStyle(TextInputStyle.Paragraph)
              .setRequired(true)
          )
        );
      return await interaction.showModal(modal);
    }

    if (interaction.isButton() && interaction.customId === "ticket_devral") {
      const staffRoleId = client.config.ticketStaffRoleID;
      if (!interaction.member.roles.cache.has(staffRoleId)) {
        return interaction.reply({
          content: "❌ Bu işlemi sadece yetkililer gerçekleştirebilir.",
          ephemeral: true
        });
      }

      const embed = interaction.message.embeds[0];
      if (!embed) {
        return interaction.reply({
          content: "❌ Mesaj embed içermiyor.",
          ephemeral: true
        });
      }

      const zatenDevralanVar = embed.description.includes("Devralan yetkili:");
      if (zatenDevralanVar) {
        return interaction.reply({
          content: "❗ Bu ticket zaten bir yetkili tarafından devralınmış.",
          ephemeral: true
        });
      }

      const yeniEmbed = EmbedBuilder.from(embed)
        .setDescription(`${embed.description}\n\n👤 **Devralan yetkili:** <@${interaction.user.id}>`)
        .setColor("Orange");

      await interaction.update({
        embeds: [yeniEmbed],
        components: interaction.message.components
      });

      await interaction.followUp({
        content: `✅ Ticket başarıyla <@${interaction.user.id}> tarafından devralındı.`,
        ephemeral: true
      });
    }

    if (interaction.isModalSubmit() && interaction.customId === "ticket_kapat_modal") {
      const reason = interaction.fields.getTextInputValue("sebep");
      const user = interaction.user;
      const channel = interaction.channel;

      const embed = new EmbedBuilder()
        .setColor("Red")
        .setTitle("🔒 Ticket Kapatıldı")
        .setDescription(`Ticket **${user.tag}** tarafından kapatıldı.\n📌 **Sebep:** ${reason}`)
        .setTimestamp();

      const today = new Date().toLocaleDateString("tr-TR");
      let loglar = [];

      if (fs.existsSync(logPath)) {
        try {
          loglar = JSON.parse(fs.readFileSync(logPath, "utf8"));
        } catch (e) {
          loglar = [];
        }
      }

      loglar.push({ date: today, kapatan: user.tag, sebep: reason });
      fs.writeFileSync(logPath, JSON.stringify(loglar, null, 2));

      try {
        const messages = await channel.messages.fetch({ limit: 100 });
        const sorted = [...messages.values()].sort((a, b) => a.createdTimestamp - b.createdTimestamp);
        const logText = sorted
          .filter(m => !m.author.bot && m.content)
          .map(m => `**${m.author.tag}:** ${m.content}`)
          .join("\n")
          .slice(0, 4000);

        const fullEmbed = new EmbedBuilder()
          .setColor("Blue")
          .setTitle(`📄 Ticket Mesaj Geçmişi: ${channel.name}`)
          .setDescription(logText || "*Mesaj bulunamadı*")
          .setTimestamp();

        const logChannel = client.channels.cache.get(client.config.ticketLogChannelID);
        if (logChannel) {
          await logChannel.send({ content: `<@${user.id}> ticket kapattı: ${channel.name}`, embeds: [embed, fullEmbed] });
        } else {
          console.warn("❗ Ticket log kanalı bulunamadı.");
        }

        await interaction.reply({ embeds: [embed] });
      } catch (err) {
        console.error("Ticket log mesajları toplanamadı:", err);
        await interaction.reply({ content: "❌ Ticket kapatıldı ancak log mesajları alınamadı.", ephemeral: true });
      }

      setTimeout(() => {
        channel.delete().catch(() => {});
      }, 5000);
    }
  }
};
