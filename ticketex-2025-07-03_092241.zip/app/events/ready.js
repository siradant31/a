module.exports = {
  name: "ready",
  run: async (client) => {
    console.log(`✅ ${client.user.tag} başarıyla giriş yaptı.`);

    const aktiviteler = [
      "ExerSec Ticket",
      "Siradant",
      "Exercitus",
      `1 sunucuda aktif!`
    ];

    let i = 0;
    setInterval(() => {
      const aktivite = aktiviteler[i % aktiviteler.length];
      client.user.setActivity(aktivite, { type: 0 }); // 0 = Oynuyor
      i++;
    }, 3000); // 3 saniyede bir değişir
  }
};