const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "messageCreate",
  run: async (client, message) => {
    const { prefix } = client.config;

    if (message.author.bot || !message.guild) return;
    if (!message.content.startsWith(prefix)) return;

    const args = message.content.slice(prefix.length).trim().split(/\s+/);
    const cmdName = args.shift().toLowerCase();
    const command = client.commands.get(cmdName);
const { handleTicketMessage } = require("../functions/ticketTimerManager");

if (message.channel.name?.startsWith("ticket-")) {
  handleTicketMessage(message.channel.id); // Yetkili yazarsa timer sıfırlanır
}
    
    // ✅ Komut yoksa embed ile uyarı ver
    if (!command) {
      const embed = new EmbedBuilder()
        .setColor("Red")
        .setTitle("❌ Komut Bulunamadı")
        .setDescription(`\`${prefix}${cmdName}\` adında bir komut bulunamadı.`)
        .setFooter({ text: "Geçerli komutları görmek için ?yardım yazabilirsin." })
        .setTimestamp();
      return message.reply({ embeds: [embed] });
    }

    // ✅ Komut çalıştırma
    try {
      await command.run(client, message, args);
    } catch (err) {
      console.error(`❌ Komut hatası: ${cmdName}`, err);
      message.reply("⚠️ Komut çalıştırılırken bir hata oluştu.");
    }
  }
};

const fs = require("fs");

module.exports = {
  name: "messageCreate",
  run: async (client, message) => {
    const { prefix } = client.config;
    if (!message.content.startsWith(prefix) || message.author.bot || !message.guild) return;

    const args = message.content.slice(prefix.length).trim().split(/\s+/);
    const cmdName = args.shift().toLowerCase();

    const command = client.commands.get(cmdName);
    if (!command) return;

    // BAKIM KONTROL (sadece ?bakım ve ?bakımkapat dışındaki tüm komutları engeller)
    const bakımVeri = JSON.parse(fs.readFileSync("./bakim.json", "utf8"));
    if (bakımVeri.aktif && !["bakım", "bakımkapat"].includes(cmdName)) {
      return message.reply({
        embeds: [{
          title: "🔧 Bot Bakımda",
          description: `Şu anda bot bakımda. Sebep:\n\n**${bakımVeri.sebep}**`,
          color: 0xffcc00,
          footer: { text: "Lütfen daha sonra tekrar deneyin." },
          timestamp: new Date()
        }]
      });
    }

    try {
      await command.run(client, message, args);
    } catch (err) {
      console.error(`❌ Komut hatası: ${cmdName}`, err);
      message.reply("⚠️ Komut çalıştırılırken bir hata oluştu.");
    }
  }
};
