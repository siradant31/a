const fs = require("fs");
const path = require("path");
const { EmbedBuilder } = require("discord.js");

const logPath = path.join(__dirname, "../veri/ticket_log.json");

module.exports = async function ticketDailyReport(client) {
  const today = new Date().toLocaleDateString("tr-TR");
  let logVeri = [];

  // JSON dosyasını oku
  try {
    if (!fs.existsSync(logPath)) return;
    const data = fs.readFileSync(logPath, "utf8");
    logVeri = JSON.parse(data);
  } catch (err) {
    console.error("❌ Günlük ticket log okunamadı:", err);
    return;
  }

  // Bugünkü kayıtları filtrele
  const bugunkuKayitlar = logVeri.filter(item => item.date === today);
  if (bugunkuKayitlar.length === 0) return;

  const duyuruYetkiliRolID = client.config.duyuruYetkiliRolID || "ROL_ID";
  const guild = client.guilds.cache.first(); // İlk sunucu
  const logChannel = guild.channels.cache.find(c => c.name.includes("ticket-log") && c.isTextBased());

  if (!logChannel) return console.log("📁 Ticket log kanalı bulunamadı.");

  const embed = new EmbedBuilder()
    .setTitle("📊 Günlük Ticket Raporu")
    .setColor("Blue")
    .setDescription(`Bugün toplam **${bugunkuKayitlar.length}** ticket kapatıldı.`)
    .addFields(
      bugunkuKayitlar.map((item, i) => ({
        name: `#${i + 1} | ${item.kapatan}`,
        value: `📝 Sebep: ${item.sebep}`
      }))
    )
    .setFooter({ text: "Ticket sistemi • Günlük rapor" })
    .setTimestamp();

  // Mesaj gönder
  try {
    await logChannel.send({ content: `<@&${duyuruYetkiliRolID}>`, embeds: [embed] });
  } catch (err) {
    console.error("📊 Günlük rapor gönderilemedi:", err);
  }
};
