const mongoose = require("mongoose");

const whitelistSchema = new mongoose.Schema({
  guildID: { type: String, required: true },
  users: { type: [String], default: [] } // Kullanıcı ID'leri listesi
});

module.exports = mongoose.model("Whitelist", whitelistSchema);
