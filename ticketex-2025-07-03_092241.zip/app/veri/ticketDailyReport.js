const fs = require("fs");
const path = require("path");
const cron = require("node-cron");
const { EmbedBuilder } = require("discord.js");

// JSON log dosyasının yolu
const logPath = path.join(__dirname, "../veri/ticket_log.json");

module.exports = (client) => {
  // Her gün saat 23:59'da çalışır
  cron.schedule("59 23 * * *", async () => {
    if (!fs.existsSync(logPath)) return;

    let logs;
    try {
      logs = JSON.parse(fs.readFileSync(logPath, "utf8"));
    } catch (err) {
      console.error("ticket_log.json okunamadı:", err);
      return;
    }

    const today = new Date().toLocaleDateString("tr-TR");

    // Bugüne ait logları filtrele
    const bugunkuler = logs.filter(log => log.date === today);
    if (bugunkuler.length === 0) return; // O gün ticket kapanmamış

    const embed = new EmbedBuilder()
      .setColor("Blurple")
      .setTitle("📊 Günlük Ticket Raporu")
      .setDescription(`Bugün toplam **${bugunkuler.length}** ticket kapatıldı.`)
      .addFields(
        bugunkuler.map((log, i) => ({
          name: `#${i + 1} • ${log.kapatan}`,
          value: `📝 Sebep: ${log.sebep}`,
          inline: false
        }))
      )
      .setFooter({ text: `Tarih: ${today}` })
      .setTimestamp();

    // Log kanalına gönder
    const kanalID = client.config.ticketLogChannelID;
    const kanal = client.channels.cache.get(kanalID);
    if (!kanal) return;

    kanal.send({ embeds: [embed] }).catch(() => {});
  });
};
