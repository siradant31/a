const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "dmduyuru",
  description: "📢 Sadece sunucu sahibi kullanır, belirli roldekilere DM gönderir",

  async run(client, message, args) {
    const hedefRolID = "1385447453255270470"; // DM gönderilecek rol

    // ✅ Sadece sunucu sahibi kullanabilir
    if (message.author.id !== message.guild.ownerId) {
      return message.reply("❌ Bu komutu kullanmak için yetkin yok.");
    }

    const duyuru = args.join(" ");
    if (!duyuru) return message.reply("❌ Kullanım: `?dmduyuru <mesaj>`");

    const embed = new EmbedBuilder()
      .setTitle("📢 Duyuru")
      .setDescription(duyuru)
      .setColor("Blue")
      .setTimestamp();

    const hedefRol = message.guild.roles.cache.get(hedefRolID);
    if (!hedefRol) {
      return message.reply("❌ Belirttiğiniz rol sunucuda bulunamadı.");
    }

    let başarı = 0;
    let başarısız = 0;

    const üyeler = hedefRol.members.filter(m => !m.user.bot);

    for (const [_, member] of üyeler) {
      try {
        await member.send({ embeds: [embed] });
        başarı++;
      } catch {
        başarısız++;
      }
    }

    message.reply(`✅ DM duyurusu tamamlandı:\n📨 Başarılı: ${başarı} kişi\n🚫 Başarısız: ${başarısız} kişi`);
  }
};
