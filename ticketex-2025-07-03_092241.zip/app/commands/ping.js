module.exports = {
  name: "ping",
  description: "Botun gecikme süresini gösterir",
  async run(client, message, args) {
    const ping = client.ws.ping;
    message.reply(`🏓 Pong! Gecikme: **${ping}ms**`);
  }
};