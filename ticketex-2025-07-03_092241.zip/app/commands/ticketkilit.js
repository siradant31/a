const fs = require("fs");
const path = require("path");
const { PermissionsBitField } = require("discord.js");

module.exports = {
  name: "ticketkilit",
  description: "🎫 Ticket açma iznini açar veya kapatır",
  async run(client, message, args) {
    const botOwnerId = "1373906120954875964";
    const isOwner = message.author.id === message.guild.ownerId;
    const isBotOwner = message.author.id === botOwnerId;
    const isAdmin = message.member.permissions.has(PermissionsBitField.Flags.Administrator);

    if (!isOwner && !isBotOwner && !isAdmin) {
      return message.reply("❌ Bu komutu kullanmak için yetkin yok.");
    }

    const veriYolu = path.join(__dirname, "../veri/ticketKilit.json");
    let durum = false;

    if (!fs.existsSync(veriYolu)) fs.writeFileSync(veriYolu, JSON.stringify({ kilitli: false }));

    const data = JSON.parse(fs.readFileSync(veriYolu, "utf8"));

    if (args[0] === "aç") {
      data.kilitli = false;
      durum = true;
    } else if (args[0] === "kapat") {
      data.kilitli = true;
      durum = false;
    } else {
      return message.reply("❌ Kullanım: `?ticketkilit aç` veya `?ticketkilit kapat`");
    }

    fs.writeFileSync(veriYolu, JSON.stringify(data, null, 2));
    message.reply(`✅ Ticket sistemi artık ${durum ? "açık" : "kapalı"}.`);
  }
};
