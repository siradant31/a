const fs = require("fs");
const path = require("path");
const { EmbedBuilder } = require("discord.js");
const { isAdmin } = require("../functions/permissionCheck");

module.exports = {
  name: "çekilişbak",
  description: "🔍 Belirtilen çekilişin geçmiş bilgilerini gösterir",
  async run(client, message, args) {
    if (!isAdmin(message)) {
      return message.reply("❌ Bu komutu kullanmak için yetkin yok.");
    }

    const msgId = args[0];
    if (!msgId) return message.reply("❌ Lütfen bir çekiliş mesaj ID'si belirt.");

    const dataPath = path.join(__dirname, "../veri/cekilisVeri.json");

    if (!fs.existsSync(dataPath)) {
      return message.reply("❌ Herhangi bir çekiliş verisi bulunamadı.");
    }

    const data = JSON.parse(fs.readFileSync(dataPath, "utf8"));
    const cekilis = data.find(item => item.mesajID === msgId);

    if (!cekilis) {
      return message.reply("❌ Belirtilen ID'ye ait bir çekiliş geçmişi bulunamadı.");
    }

    const embed = new EmbedBuilder()
      .setTitle("📋 Çekiliş Detayları")
      .setColor("Blurple")
      .addFields(
        { name: "🎁 Ödül", value: cekilis.odul, inline: true },
        { name: "👑 Kazanan", value: `<@${cekilis.kazanan}>`, inline: true },
        { name: "📅 Tarih", value: cekilis.tarih, inline: true },
        { name: "🆔 Mesaj ID", value: cekilis.mesajID, inline: true }
      )
      .setFooter({ text: `${message.guild.name} • Çekiliş Bilgisi` })
      .setTimestamp();

    message.channel.send({ embeds: [embed] });
  }
};
