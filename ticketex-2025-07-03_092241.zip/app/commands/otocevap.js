const fs = require("fs");
const path = require("path");
const { PermissionsBitField } = require("discord.js");

const dosyaYolu = path.join(__dirname, "../veri/otocevaplar.json");

module.exports = {
  name: "otocevap",
  description: "🧠 Anahtar kelimeye karşılık otomatik yanıt belirler",

  async run(client, message, args) {
    if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
      return message.reply("❌ Bu komutu kullanmak için yetkin yok.");
    }

    const [anahtar, ...cevap] = args;
    if (!anahtar || cevap.length === 0) {
      return message.reply("❌ Kullanım: `?otocevap <anahtar> <cevap>`");
    }

    let veriler = {};
    if (fs.existsSync(dosyaYolu)) {
      veriler = JSON.parse(fs.readFileSync(dosyaYolu, "utf8"));
    }

    veriler[anahtar.toLowerCase()] = cevap.join(" ");
    fs.writeFileSync(dosyaYolu, JSON.stringify(veriler, null, 2));

    message.reply(`✅ \`${anahtar}\` kelimesine artık şu yanıt verilecek:\n> ${cevap.join(" ")}`);
  }
};
