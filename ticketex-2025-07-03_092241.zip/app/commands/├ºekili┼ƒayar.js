const { EmbedBuilder } = require("discord.js");
const { isAdmin } = require("../functions/permissionCheck");

module.exports = {
  name: "çekilişayar",
  description: "⚙️ Çekiliş sistemine ait ayarları gösterir",
  async run(client, message) {
    if (!isAdmin(message)) {
      return message.reply("❌ Bu komutu kullanmak için yetkin yok.");
    }

    const ayarlar = {
      minimumSüre: "5 saniye",
      kayıtYolu: "./veri/cekilisVeri.json",
      kayıtTipi: "JSON (yerel kayıt)",
      desteklenenSüreBiçimleri: "1s, 1m, 1h, 1d",
      komutlar: [
        "çekiliş", "çekilişliste", "çekilişbak", 
        "çekilişiptal", "çekilişyenile", "çekilişkatılanlar"
      ]
    };

    const embed = new EmbedBuilder()
      .setTitle("⚙️ Çekiliş Ayarları")
      .setColor("Yellow")
      .setDescription(
        `📁 **Veri Kaydı:** ${ayarlar.kayıtYolu}\n` +
        `📌 **Minimum Süre:** ${ayarlar.minimumSüre}\n` +
        `🕒 **Desteklenen Süreler:** ${ayarlar.desteklenenSüreBiçimleri}\n` +
        `💾 **Kayıt Tipi:** ${ayarlar.kayıtTipi}\n\n` +
        `📜 **Mevcut Komutlar:**\n\`\`\`${ayarlar.komutlar.join(", ")}\`\`\``
      )
      .setFooter({ text: `${message.guild.name} • Çekiliş Sistemi` })
      .setTimestamp();

    message.channel.send({ embeds: [embed] });
  }
};
