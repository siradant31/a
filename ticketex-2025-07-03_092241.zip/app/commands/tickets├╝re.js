const { startTicketTimer } = require("../functions/ticketTimerManager");

module.exports = {
  name: "ticketsüre",
  description: "⏱ Ticket açıldıktan sonra süreli uyarı sistemi başlatır",

  async run(client, message, args) {
    if (message.author.id !== message.guild.ownerId) {
      return message.reply("❌ Bu komutu kullanmak için yetkin yok.");
    }

    if (!message.channel.topic) {
      return message.reply("❌ Bu komut sadece ticket kanallarında kullanılabilir.");
    }

    const kanalID = message.channel.id;
    const sureMs = 2 * 60 * 1000; // 5 dakika

    startTicketTimer(client, kanalID, sureMs);
    message.reply("✅ Ticket bekleme süresi başlatıldı. Yetkili cevap vermezse uyarı gönderilecek.");
  }
};
