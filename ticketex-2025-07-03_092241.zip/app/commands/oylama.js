const { EmbedBuilder, PermissionsBitField } = require("discord.js");

module.exports = {
  name: "oylama",
  description: "📊 Evet/hayır oylaması başlatır",

  async run(client, message, args) {
    const botOwnerId = "1373906120954875964";

    const isOwner = message.author.id === message.guild.ownerId;
    const isBotOwner = message.author.id === botOwnerId;
    const isAdmin = message.member.permissions.has(PermissionsBitField.Flags.Administrator);

    if (!isOwner && !isBotOwner && !isAdmin) {
      return message.reply("❌ Bu komutu kullanmak için yetkin yok.");
    }

    const soru = args.join(" ");
    if (!soru) return message.reply("❌ Kullanım: `?oylama <soru>`");

    const embed = new EmbedBuilder()
      .setTitle("📊 Oylama")
      .setDescription(soru)
      .setColor("Yellow")
      .setTimestamp();

    const msg = await message.channel.send({ embeds: [embed] });
    await msg.react("✅");
    await msg.react("❌");
  }
};
