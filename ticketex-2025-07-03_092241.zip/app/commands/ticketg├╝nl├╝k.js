const fs = require("fs");
const path = require("path");
const { EmbedBuilder, PermissionsBitField } = require("discord.js");

module.exports = {
  name: "ticketgünlük",
  description: "📅 Bugün açılan ve kapatılan ticket sayısını gösterir",
  async run(client, message) {
    const botOwnerId = "1373906120954875964";
    const isOwner = message.author.id === message.guild.ownerId;
    const isBotOwner = message.author.id === botOwnerId;
    const isAdmin = message.member.permissions.has(PermissionsBitField.Flags.Administrator);

    if (!isOwner && !isBotOwner && !isAdmin) {
      return message.reply("❌ Bu komutu kullanmak için yetkin yok.");
    }

    const today = new Date().toLocaleDateString("tr-TR");
    const logPath = path.join(__dirname, "../veri/ticket_log.json");

    if (!fs.existsSync(logPath)) return message.reply("📁 Log dosyası yok.");

    const logs = JSON.parse(fs.readFileSync(logPath, "utf8"));
    const bugun = logs.filter(l => l.date === today);

    const embed = new EmbedBuilder()
      .setTitle("📅 Günlük Ticket Raporu")
      .setColor("Blue")
      .setDescription(`📌 Bugün kapatılan ticket sayısı: **${bugun.length}**`)
      .setTimestamp();

    message.channel.send({ embeds: [embed] });
  }
};
