const fs = require("fs");
const path = require("path");

module.exports = {
  name: "ticketlogsil",
  description: "🗑️ Tüm ticket log geçmişini siler. (Sadece sunucu sahibi kullanabilir)",

  run: async (client, message) => {
    const logPath = path.join(__dirname, "../veri/ticket_log.json");

    if (message.author.id !== message.guild.ownerId) {
      return message.reply("❌ Bu komutu kullanmak için yetkin yok.");
    }

    if (!fs.existsSync(logPath)) {
      return message.reply("⚠️ Ticket geçmişi zaten boş.");
    }

    try {
      fs.writeFileSync(logPath, JSON.stringify([], null, 2), "utf8");
      message.reply("✅ Ticket log geçmişi başarıyla silindi.");
    } catch (err) {
      console.error("ticketlogsil.js | Silme hatası:", err);
      message.reply("❌ Ticket log silinirken bir hata oluştu.");
    }
  }
};
