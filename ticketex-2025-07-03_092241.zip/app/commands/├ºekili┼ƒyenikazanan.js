const fs = require("fs");
const path = require("path");
const { EmbedBuilder } = require("discord.js");
const { isAdmin } = require("../functions/permissionCheck");

module.exports = {
  name: "çekilişyenikazanan",
  description: "🎯 Geçmiş çekilişten yeni bir kazanan belirler",
  async run(client, message, args) {
    if (!isAdmin(message)) {
      return message.reply("❌ Bu komutu kullanmak için yetkin yok.");
    }

    const msgId = args[0];
    if (!msgId) return message.reply("❌ Lütfen çekiliş mesaj ID'sini girin.");

    const dataPath = path.join(__dirname, "../veri/cekilisVeri.json");

    if (!fs.existsSync(dataPath)) {
      return message.reply("❌ Herhangi bir çekiliş verisi bulunamadı.");
    }

    const data = JSON.parse(fs.readFileSync(dataPath, "utf8"));
    const cekilis = data.find(c => c.messageId === msgId);

    if (!cekilis || !cekilis.katilanlar || cekilis.katilanlar.length === 0) {
      return message.reply("❌ Bu çekilişe ait yeterli katılımcı verisi bulunamadı.");
    }

    const yeniKazananId = cekilis.katilanlar[Math.floor(Math.random() * cekilis.katilanlar.length)];
    cekilis.kazanan = yeniKazananId;

    fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));

    const embed = new EmbedBuilder()
      .setTitle("🔄 Yeni Kazanan Seçildi!")
      .setDescription(`🎁 Ödül: **${cekilis.odul}**\n🎉 Yeni Kazanan: <@${yeniKazananId}>`)
      .setColor("Gold")
      .setFooter({ text: `${message.guild.name} • Yeniden Çekiliş` })
      .setTimestamp();

    message.channel.send({ embeds: [embed] });
  }
};
