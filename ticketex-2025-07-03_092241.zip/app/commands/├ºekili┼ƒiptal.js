const { isAdmin } = require("../functions/permissionCheck");

module.exports = {
  name: "çekilişiptal",
  description: "🗑️ Belirtilen çekilişi iptal eder",
  async run(client, message, args) {
    if (!isAdmin(message)) {
      return message.reply("❌ Bu komutu kullanmak için yetkin yok.");
    }

    const msgId = args[0];
    if (!msgId) return message.reply("❌ Lütfen iptal etmek istediğin çekilişin mesaj ID'sini belirt.");

    try {
      const msg = await message.channel.messages.fetch(msgId);
      if (!msg) return message.reply("❌ Belirtilen ID'ye ait bir çekiliş mesajı bulunamadı.");

      await msg.edit({
        content: "🚫 Bu çekiliş iptal edilmiştir.",
        components: []
      });

      message.reply("✅ Çekiliş başarıyla iptal edildi.");
    } catch (err) {
      console.error("Çekiliş iptal hatası:", err);
      message.reply("❌ Çekilişi iptal ederken bir hata oluştu.");
    }
  }
};
