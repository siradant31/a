const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const ms = require("ms");
const fs = require("fs");
const path = require("path");
const { isAdmin } = require("../functions/permissionCheck");

const ayarPath = path.join(__dirname, "../veri/cekilis_ayar.json");
const veriYolu = path.join(__dirname, "../veri/cekilisVeri.json");

module.exports = {
  name: "çekiliş",
  description: "🎁 Süreli çekiliş başlatır (Yalnızca adminler kullanabilir)",

  async run(client, message, args) {
    if (!isAdmin(message)) {
      return message.reply("❌ Bu komutu kullanmak için yetkin yok.");
    }

    if (!args[0] || !args[1]) {
      return message.reply("❌ Kullanım: `?çekiliş <süre> <ödül>`\nÖrnek: `?çekiliş 1m Nitro`");
    }

    const sure = ms(args[0]);
    if (!sure || sure < 5000) return message.reply("❌ Geçerli bir süre girin! (örn: 30s, 1m, 1h)");

    const odul = args.slice(1).join(" ");
    const bitisZamani = Date.now() + sure;

    const embed = new EmbedBuilder()
      .setTitle("🎉 Yeni Çekiliş!")
      .setDescription(`🎁 **Ödül:** ${odul}\n\n⏰ **Süre:** ${args[0]}\n\n🎟️ Katılmak için __Katıl__ butonuna tıkla!`)
      .setColor("Green")
      .setFooter({ text: `Bitiş: ${new Date(bitisZamani).toLocaleString()}` });

    const button = new ButtonBuilder()
      .setCustomId("cekilis_katil")
      .setLabel("Katıl")
      .setStyle(ButtonStyle.Success);

    const row = new ActionRowBuilder().addComponents(button);
    const msg = await message.channel.send({ embeds: [embed], components: [row] });
    const katilanlar = new Set();

    if (!fs.existsSync(veriYolu)) fs.writeFileSync(veriYolu, "[]", "utf8");

    const collector = msg.createMessageComponentCollector({ time: sure });

    collector.on("collect", interaction => {
      if (interaction.customId !== "cekilis_katil") return;
      if (katilanlar.has(interaction.user.id)) {
        return interaction.reply({ content: "❌ Zaten katıldın!", ephemeral: true });
      }
      katilanlar.add(interaction.user.id);
      interaction.reply({ content: "✅ Çekilişe katıldın, bol şans!", ephemeral: true });
    });

    collector.on("end", async () => {
      msg.edit({ components: [] });

      let kazananId = null;
      if (katilanlar.size > 0) {
        kazananId = Array.from(katilanlar)[Math.floor(Math.random() * katilanlar.size)];
      }

      const sonucEmbed = new EmbedBuilder()
        .setTitle("🎉 Çekiliş Bitti!")
        .setDescription(`🎁 **Ödül:** ${odul}\n👑 **Kazanan:** ${kazananId ? `<@${kazananId}>` : "_Yok_"}\n👥 **Katılım:** ${katilanlar.size}`)
        .setColor("Blue")
        .setTimestamp();

      msg.reply({ content: kazananId ? `🎊 Tebrikler <@${kazananId}>!` : "Katılım olmadı.", embeds: [sonucEmbed] });

      // 🔔 DM Gönderimi Açık mı kontrolü
      let dmAyar = { cekilisDmAktif: true };
      if (fs.existsSync(ayarPath)) {
        try {
          dmAyar = JSON.parse(fs.readFileSync(ayarPath, "utf8"));
        } catch (e) {
          dmAyar = { cekilisDmAktif: true };
        }
      }

      if (kazananId && dmAyar.cekilisDmAktif) {
        try {
          const kazananUser = await client.users.fetch(kazananId);
          kazananUser.send(`🎉 Tebrikler! \`${odul}\` ödüllü bir çekilişi kazandınız!\nSunucu: **${message.guild.name}**`).catch(() => {});
        } catch (e) {
          console.warn("DM gönderilemedi:", e.message);
        }
      }

      // 📁 JSON log kaydı
      let veriler = [];
      try {
        veriler = JSON.parse(fs.readFileSync(veriYolu, "utf8"));
      } catch (e) {
        veriler = [];
      }

      veriler.push({
        mesajID: msg.id,
        kanalID: msg.channel.id,
        odul: odul,
        kazanan: kazananId || "Yok",
        katilim: katilanlar.size,
        tarih: new Date().toLocaleString("tr-TR")
      });

      fs.writeFileSync(veriYolu, JSON.stringify(veriler, null, 2), "utf8");
    });
  }
};