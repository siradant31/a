const fs = require("fs");
const path = require("path");
const { EmbedBuilder, PermissionsBitField } = require("discord.js");

module.exports = {
  name: "ticketlog",
  description: "📁 Kapatılan ticket geçmişini gösterir.",
  run: async (client, message, args) => {
    const botOwnerId = "1373906120954875964";
    const isOwner = message.author.id === message.guild.ownerId;
    const isBotOwner = message.author.id === botOwnerId;
    const isAdmin = message.member.permissions.has(PermissionsBitField.Flags.Administrator);

    if (!isOwner && !isBotOwner && !isAdmin) {
      return message.reply("❌ Bu komutu kullanmak için yetkin yok.");
    }

    const logPath = path.join(__dirname, "../veri/ticket_log.json");

    if (!fs.existsSync(logPath)) {
      return message.reply("📁 Henüz ticket geçmişi bulunmuyor.");
    }

    let logs;
    try {
      logs = JSON.parse(fs.readFileSync(logPath, "utf8"));
    } catch (e) {
      return message.reply("❌ Ticket log dosyası okunurken bir hata oluştu.");
    }

    if (!logs.length) {
      return message.reply("📁 Henüz kapatılmış bir ticket bulunmuyor.");
    }

    const embed = new EmbedBuilder()
      .setTitle("📁 Ticket Log Geçmişi")
      .setColor("Blurple")
      .setDescription(
        logs
          .slice(-10) // Son 10 ticket
          .reverse()
          .map((log, i) => `**${i + 1}.** 📅 ${log.date} | 👤 ${log.kapatan} | 📌 Sebep: ${log.sebep}`)
          .join("\n\n")
      )
      .setFooter({ text: `${logs.length} ticket kaydı listelendi` });

    message.reply({ embeds: [embed] });
  }
};
