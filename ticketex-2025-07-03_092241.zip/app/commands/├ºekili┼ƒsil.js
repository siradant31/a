const fs = require("fs");
const path = require("path");
const { isAdmin } = require("../functions/permissionCheck");

module.exports = {
  name: "çekilişsil",
  description: "🧹 Belirtilen çekilişi tamamen siler (mesaj + veri)",
  async run(client, message, args) {
    // Admin yetki kontrolü
    if (!isAdmin(message)) {
      return message.reply("❌ Bu komutu kullanmak için yetkin yok.");
    }

    const msgId = args[0];
    if (!msgId) return message.reply("❌ Lütfen silmek istediğin çekilişin mesaj ID'sini belirt.");

    try {
      // Mesaj sil
      const msg = await message.channel.messages.fetch(msgId);
      if (msg) await msg.delete();

      // Veri dosyasından çekilişi kaldır
      const dataPath = path.join(__dirname, "../veri/cekilisVeri.json");
      let data = [];

      if (fs.existsSync(dataPath)) {
        data = JSON.parse(fs.readFileSync(dataPath, "utf8"));
      }

      data = data.filter(item => item.messageId !== msgId);
      fs.writeFileSync(dataPath, JSON.stringify(data, null, 2), "utf8");

      message.reply("✅ Çekiliş başarıyla silindi.");
    } catch (err) {
      console.error("çekilişsil.js | Silme hatası:", err);
      message.reply("❌ Çekilişi silerken bir hata oluştu.");
    }
  }
};
