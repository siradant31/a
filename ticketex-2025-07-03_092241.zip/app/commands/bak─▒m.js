const fs = require("fs");
const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "bakım",
  description: "Botu bakım moduna alır (sadece sahibi)",

  async run(client, message, args) {
    if (message.author.id !== message.ownerId) {
      return message.reply("❌ Bu komutu kullanmak için yetkin yok.");
    }

    const sebep = args.join(" ");
    if (!sebep) return message.reply("❌ Lütfen bakım sebebini yaz.");

    const bakımVeri = {
      aktif: true,
      sebep: sebep
    };
    fs.writeFileSync("./bakim.json", JSON.stringify(bakımVeri, null, 2));

    const embed = new EmbedBuilder()
      .setColor("Yellow")
      .setTitle("🔧 Bot Bakımda")
      .setDescription(`Bot şu sebeple bakıma alındı:\n\n**${sebep}**`)
      .setFooter({ text: "Tüm komutlar geçici olarak devre dışı." })
      .setTimestamp();

    message.reply({ embeds: [embed] });
  }
};
