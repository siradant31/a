const { PermissionsBitField } = require("discord.js");

module.exports = {
  name: "sil",
  description: "🧹 Belirtilen sayıda mesajı siler",

  async run(client, message, args) {
    const botOwnerId = "1373906120954875964";
    const isOwner = message.author.id === message.guild.ownerId;
    const isBotOwner = message.author.id === botOwnerId;
    const isAdmin = message.member.permissions.has(PermissionsBitField.Flags.Administrator);

    if (!isOwner && !isBotOwner && !isAdmin) {
      return message.reply("❌ Bu komutu kullanmak için yetkin yok.");
    }

    const miktar = parseInt(args[0]);

    if (!miktar || isNaN(miktar) || miktar < 1 || miktar > 100) {
      return message.reply("❌ 1 ile 100 arasında bir sayı girmelisin. Örn: `?sil 50`");
    }

    try {
      await message.channel.bulkDelete(miktar, true);
      const msg = await message.channel.send(`✅ Başarıyla **${miktar}** mesaj silindi!`);
      setTimeout(() => msg.delete().catch(() => {}), 3000);
    } catch (err) {
      console.error(err);
      message.reply("❌ Mesajlar silinirken bir hata oluştu.");
    }
  }
};
