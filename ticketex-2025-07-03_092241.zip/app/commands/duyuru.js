const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "duyuru",
  description: "Belirtilen kanala duyuru gönderir. (Sadece yetkililer kullanabilir)",

  async run(client, message, args) {
    const yetkiliRolID = client.config.duyuruYetkiliRolID;

    // Yetkili kontrolü
    if (
      !message.member.roles.cache.has(yetkiliRolID) &&
      message.author.id !== message.guild.ownerId
    ) {
      return message.reply("❌ Bu komutu kullanmak için yetkin yok.");
    }

    // Kanal ve mesaj kontrolü
    const kanal = message.mentions.channels.first();
    const duyuruMesajı = args.slice(1).join(" ");

    if (!kanal) {
      return message.reply("❌ Lütfen geçerli bir kanal etiketle. Örn: `?duyuru #kanal Mesaj`");
    }

    if (!duyuruMesajı) {
      return message.reply("❌ Lütfen gönderilecek duyuru mesajını da yaz.");
    }

    // Embed duyuru
    const embed = new EmbedBuilder()
      .setTitle("📢 Yeni Duyuru")
      .setDescription(duyuruMesajı)
      .setColor("Orange")
      .setFooter({ text: `Duyuru yapan: ${message.author.tag}` })
      .setTimestamp();

    try {
      await kanal.send({ embeds: [embed] });
      return message.reply("✅ Duyuru başarıyla gönderildi.");
    } catch (err) {
      console.error("📢 Duyuru gönderilemedi:", err);
      return message.reply("❌ Duyuru gönderilirken bir hata oluştu.");
    }
  }
};
