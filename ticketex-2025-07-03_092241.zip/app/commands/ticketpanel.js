const { ActionRowBuilder, StringSelectMenuBuilder, EmbedBuilder } = require("discord.js");

module.exports = {
  name: "ticketpanel",
  description: "🎫 Destek panelini gönderir.",

  async run(client, message, args) {
    if (message.author.id !== message.guild.ownerId) {
      return message.reply("❌ Bu komutu kullanmak için yetkin yok.");
    }

    const embed = new EmbedBuilder()
      .setTitle("🎫 Destek Paneli")
      .setDescription(
        "Aşağıdan bir kategori seçerek ticket oluşturabilirsiniz."
      )
      .setImage("https://cdn.glitch.global/7edde908-6572-464e-b561-b49fbb7bdc75/standard%20(4).gif?v=1751228352095")
      .addFields({
        name: "📌 Önemli!",
        value: "Lütfen doğru kategori seçtiğinizden emin olun."
      })
      .setColor("Blue")
      .setFooter({ text: `${client.user.username} Ticket Sistemi`, iconURL: client.user.displayAvatarURL() })
      .setTimestamp();

    const select = new StringSelectMenuBuilder()
      .setCustomId("ticket_kategori_sec")
      .setPlaceholder("📂 Bir destek kategorisi seçin")
      .addOptions([
        {
          label: "🔧 Genel Destek",
          value: "Genel",
          description: "Genel sorunlar ve yardım talepleri"
        },
        {
          label: "💳 Satın Alma",
          value: "Satın Alım",
          description: "Ödeme ve satın alma işlemleri"
        },
        {
          label: "🚨 Oyuncu Şikayet",
          value: "Oyuncu Şikayet",
          description: "Sunucudaki oyuncular hakkında şikayet"
        },
        {
          label: "🌟 VIP Bilgi",
          value: "VIP Bilgi",
          description: "VIP sistemleri hakkında bilgi"
        },
        {
          label: "⛔ Ban İtiraz",
          value: "Ban İtiraz",
          description: "Haksız ban itirazı oluştur"
        },
        {
          label: "🖥️ Teknik Sorun",
          value: "Teknik",
          description: "Bot, sistem ve diğer teknik konular"
        },
        {
          label: "↩️ Seçimi Sıfırla",
          value: "reset",
          description: "Menüyü Yenile"
        }
      ]);

    const row = new ActionRowBuilder().addComponents(select);

    message.channel.send({ embeds: [embed], components: [row] });
  }
};
