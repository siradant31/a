const fs = require("fs");
const path = require("path");
const { isServerOwner } = require("../functions/permissionCheck");

module.exports = {
  name: "yetkilirol",
  description: "🎟️ Ticket yetkilisi rolünü ayarlar",

  async run(client, message, args) {
    if (!isServerOwner(message)) {
      return message.reply("❌ Bu komutu kullanmak için yetkin yok.");
    }

    const rol = message.mentions.roles.first();
    if (!rol) return message.reply("❌ Lütfen bir rol etiketleyin. Örnek: `?yetkilirol @yetkili`");

    const configPath = path.join(__dirname, "../config.json");

    try {
      const config = require(configPath);
      config.ticketStaffRole = rol.id;
      fs.writeFileSync(configPath, JSON.stringify(config, null, 2));

      message.reply(`✅ Ticket yetkili rolü başarıyla ayarlandı: <@&${rol.id}>`);
    } catch (err) {
      console.error("yetkilirol.js | Config hatası:", err);
      message.reply("❌ Bir hata oluştu, rol ayarlanamadı.");
    }
  }
};
