const fs = require("fs");
const path = require("path");
const { isServerOwner } = require("../functions/permissionCheck");

module.exports = {
  name: "çekilişlogsil",
  description: "🗑️ Tüm çekiliş geçmişini siler. (Sadece sunucu sahibi kullanabilir)",
  async run(client, message, args) {
    if (!isServerOwner(message)) {
      return message.reply("❌ Bu komutu kullanmak için yetkin yok.");
    }

    const logPath = path.join(__dirname, "../veri/cekilisVeri.json");

    if (!fs.existsSync(logPath)) {
      return message.reply("⚠️ Çekiliş geçmişi zaten boş.");
    }

    try {
      fs.writeFileSync(logPath, JSON.stringify([], null, 2), "utf8");
      message.reply("✅ Çekiliş geçmişi başarıyla silindi.");
    } catch (err) {
      console.error("çekilişlogsil.js | Silme hatası:", err);
      message.reply("❌ Çekiliş geçmişi silinirken bir hata oluştu.");
    }
  }
};
