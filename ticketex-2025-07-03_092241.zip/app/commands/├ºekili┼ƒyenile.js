const { EmbedBuilder } = require("discord.js");
const { isAdmin } = require("../functions/permissionCheck");

module.exports = {
  name: "çekilişyenile",
  description: "🎲 Kazananı yeniden belirler (sadece açık çekilişlerde)",
  async run(client, message, args) {
    if (!isAdmin(message)) {
      return message.reply("❌ Bu komutu kullanmak için yetkin yok.");
    }

    const msgId = args[0];
    if (!msgId) return message.reply("❌ Yenilemek istediğin çekilişin mesaj ID'sini belirt.");

    try {
      const msg = await message.channel.messages.fetch(msgId);
      if (!msg || !msg.components?.length) return message.reply("❌ Geçerli bir çekiliş mesajı bulunamadı.");

      const katilanlar = new Set();
      const collector = msg.createMessageComponentCollector({ time: 2000 });

      msg.components[0].components[0].disabled = true;
      msg.edit({ components: msg.components });

      // Katılan kullanıcıları topla
      collector.on("collect", i => {
        if (i.customId === "cekilis_katil") katilanlar.add(i.user.id);
      });

      collector.on("end", () => {
        if (katilanlar.size === 0) return message.reply("❌ Bu çekilişte katılım yok.");

        const kazanan = Array.from(katilanlar)[Math.floor(Math.random() * katilanlar.size)];

        const embed = new EmbedBuilder()
          .setTitle("🔁 Çekiliş Yenilendi!")
          .setDescription(`🎁 Yeni Kazanan: <@${kazanan}>`)
          .setColor("Orange")
          .setTimestamp();

        message.channel.send({ embeds: [embed] });
      });
    } catch (err) {
      console.error("Çekiliş yenileme hatası:", err);
      return message.reply("❌ Yenileme sırasında bir hata oluştu.");
    }
  }
};
