const fs = require("fs");
const path = require("path");
const { EmbedBuilder, PermissionsBitField } = require("discord.js");

module.exports = {
  name: "katılansay",
  description: "🎫 Ticket açan kişi sayısını ve kullanıcıları listeler.",
  
  async run(client, message, args) {
    const botOwnerID = "1373906120954875964";

    const isAdmin = message.member.permissions.has(PermissionsBitField.Flags.Administrator);
    const isGuildOwner = message.author.id === message.guild?.ownerId;
    const isBotOwner = message.author.id === botOwnerID;

    if (!isAdmin && !isGuildOwner && !isBotOwner) {
      return message.reply("❌ Bu komutu kullanmak için yetkin yok.");
    }

    const dosyaYolu = path.join(__dirname, "../veri/ticketKullanicilar.json");

    let liste = [];
    try {
      liste = JSON.parse(fs.readFileSync(dosyaYolu, "utf8"));
    } catch (err) {
      return message.reply("❌ Kullanıcı verisi okunamadı.");
    }

    const toplam = liste.length;
    const kisiListesi = liste.map((id, i) => `${i + 1}. <@${id}>`).join("\n") || "Henüz kimse ticket açmamış.";

    const embed = new EmbedBuilder()
      .setTitle("🎫 Ticket Açanlar")
      .setDescription(`Toplam: **${toplam} kişi** ticket açmış.\n\n${kisiListesi}`)
      .setColor("Green")
      .setTimestamp();

    message.reply({ embeds: [embed] });
  }
};
