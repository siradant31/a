const { EmbedBuilder } = require("discord.js");
const fs = require("fs");
const path = require("path");
const { isAdmin } = require("../functions/permissionCheck");

module.exports = {
  name: "çekilişliste",
  description: "🎁 Aktif ve geçmiş çekilişleri listeler",
  async run(client, message, args) {
    if (!isAdmin(message)) {
      return message.reply("❌ Bu komutu kullanmak için yetkin yok.");
    }

    const dataPath = path.join(__dirname, "../veri/cekilisVeri.json");
    let veri = [];

    try {
      if (fs.existsSync(dataPath)) {
        veri = JSON.parse(fs.readFileSync(dataPath, "utf8"));
      }
    } catch (e) {
      return message.reply("❌ Çekiliş verileri okunamadı.");
    }

    const aktifler = client.aktifCekilisler || [];

    if (aktifler.length === 0 && veri.length === 0) {
      return message.reply("📭 Şu anda hiçbir aktif veya geçmiş çekiliş bulunmuyor.");
    }

    const embed = new EmbedBuilder()
      .setTitle("📋 Çekiliş Listesi")
      .setColor("DarkVividPink");

    if (aktifler.length > 0) {
      embed.addFields({
        name: "🎉 Aktif Çekilişler",
        value: aktifler.map((cekilis, i) =>
          `\`${i + 1}.\` 🎁 **${cekilis.odul}** — Bitiş: <t:${Math.floor(cekilis.bitis / 1000)}:R>`
        ).join("\n")
      });
    }

    if (veri.length > 0) {
      embed.addFields({
        name: "📦 Geçmiş Çekilişler",
        value: veri.slice(-5).reverse().map((cekilis, i) =>
          `\`${i + 1}.\` 🎁 **${cekilis.odul}** — 👑 <@${cekilis.kazanan}> — 🕒 ${cekilis.tarih}`
        ).join("\n")
      });
    }

    return message.channel.send({ embeds: [embed] });
  }
};
