const fs = require("fs");
const path = require("path");
const { EmbedBuilder } = require("discord.js");
const { isAdmin } = require("../functions/permissionCheck");

module.exports = {
  name: "çekilişkatılanlar",
  description: "📋 Belirtilen çekilişe katılan kişileri listeler",
  async run(client, message, args) {
    if (!isAdmin(message)) {
      return message.reply("❌ Bu komutu kullanmak için yetkin yok.");
    }

    const msgId = args[0];
    if (!msgId) return message.reply("❌ Lütfen çekiliş mesaj ID'sini girin.");

    const dataPath = path.join(__dirname, "../veri/cekilisVeri.json");
    if (!fs.existsSync(dataPath)) {
      return message.reply("❌ Çekiliş verisi bulunamadı.");
    }

    const data = JSON.parse(fs.readFileSync(dataPath, "utf8"));
    const cekilis = data.find(c => c.messageId === msgId);

    if (!cekilis) {
      return message.reply("❌ Belirtilen ID'ye ait çekiliş bulunamadı.");
    }

    if (!cekilis.katilanlar || cekilis.katilanlar.length === 0) {
      return message.reply("❌ Bu çekilişe kimse katılmamış.");
    }

    const liste = cekilis.katilanlar.map((id, index) => `${index + 1}. <@${id}>`).join("\n");

    const embed = new EmbedBuilder()
      .setTitle("📋 Katılımcı Listesi")
      .setDescription(`**Ödül:** ${cekilis.odul}\n**Toplam Katılım:** ${cekilis.katilanlar.length}\n\n${liste}`)
      .setColor("Blue")
      .setFooter({ text: `${message.guild.name} • Katılanlar` })
      .setTimestamp();

    message.channel.send({ embeds: [embed] });
  }
};
