const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "say",
  description: "Sunucunun istatistiklerini gösterir.",

  async run(client, message) {
    const { guild } = message;

    const totalMembers = guild.memberCount;
    const onlineMembers = guild.members.cache.filter(m => m.presence?.status === "online").size;
    const idleMembers = guild.members.cache.filter(m => m.presence?.status === "idle").size;
    const dndMembers = guild.members.cache.filter(m => m.presence?.status === "dnd").size;
    const botCount = guild.members.cache.filter(m => m.user.bot).size;
    const boostCount = guild.premiumSubscriptionCount || 0;

    const embed = new EmbedBuilder()
      .setTitle("📊 Sunucu İstatistikleri")
      .setColor("Blue")
      .addFields(
        { name: "👥 Toplam Üye", value: `${totalMembers}`, inline: true },
        { name: "🤖 Bot Sayısı", value: `${botCount}`, inline: true },
        { name: "💬 Aktif (Online)", value: `${onlineMembers}`, inline: true },
        { name: "🌙 Boşta (Idle)", value: `${idleMembers}`, inline: true },
        { name: "⛔ Rahatsız Etmeyin", value: `${dndMembers}`, inline: true },
        { name: "🚀 Boost Sayısı", value: `${boostCount}`, inline: true }
      )
      .setFooter({ text: `${guild.name} Sunucu Sayacı` })
      .setTimestamp();

    message.reply({ embeds: [embed] });
  }
};
