const { EmbedBuilder } = require("discord.js");
const fs = require("fs");
const path = require("path");

const configPath = path.join(__dirname, "../config.json");

module.exports = {
  name: "ticketlogkanal",
  description: "📁 Ticket açma/kapama loglarının gönderileceği kanalı ayarlarsın.",

  async run(client, message, args) {
    if (message.author.id !== message.guild.ownerId) {
      return message.reply("❌ Bu komutu kullanmak için yetkin yok.");
    }

    const channel = message.mentions.channels.first();
    if (!channel) {
      return message.reply("❌ Lütfen bir kanal etiketleyin. Örnek: `?ticketlogkanal #log-kanalı`");
    }

    try {
      const config = require(configPath);
      config.ticketLogChannelID = channel.id;
      fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
    } catch (err) {
      console.error("❌ Config yazma hatası:", err);
      return message.reply("❌ Bir hata oluştu, kanal ayarlanamadı.");
    }

    const embed = new EmbedBuilder()
      .setColor("Green")
      .setTitle("✅ Ticket Log Kanalı Ayarlandı")
      .setDescription(`🎫 Ticket logları artık ${channel} kanalına gönderilecek.`)
      .setTimestamp();

    message.reply({ embeds: [embed] });
  }
};
