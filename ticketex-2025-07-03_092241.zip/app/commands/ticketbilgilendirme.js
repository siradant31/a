const { EmbedBuilder, PermissionsBitField } = require("discord.js");

module.exports = {
  name: "ticketbilgilendirme",
  description: "🎫 Seçilen kanala bilgilendirme mesajı gönderir.",
  run: async (client, message, args) => {
    const botOwnerId = "1373906120954875964";
    const isOwner = message.author.id === message.guild.ownerId;
    const isBotOwner = message.author.id === botOwnerId;
    const isAdmin = message.member.permissions.has(PermissionsBitField.Flags.Administrator);

    if (!isOwner && !isBotOwner && !isAdmin) {
      return message.reply("❌ Bu komutu kullanmak için yetkin yok.");
    }

    const kanal = message.mentions.channels.first();
    const metin = args.slice(1).join(" ");

    if (!kanal || !metin) {
      return message.reply("❌ Kullanım: `?ticketbilgilendirme #kanal mesaj`").then(msg => {
        setTimeout(() => msg.delete().catch(() => {}), 3000);
      });
    }

    const embed = new EmbedBuilder()
      .setTitle("🎫 Ticket Bilgilendirme")
      .setDescription(metin)
      .setColor("Blue")
      .setTimestamp();

    try {
      await kanal.send({ embeds: [embed] });

      const infoMsg = await message.reply(`✅ Bilgilendirme mesajı başarıyla ${kanal} kanalına gönderildi.`);
      setTimeout(() => infoMsg.delete().catch(() => {}), 7000);

    } catch (err) {
      console.error("❌ Mesaj gönderme hatası:", err);
      const errorMsg = await message.channel.send("❌ Mesaj gönderilemedi.");
      setTimeout(() => errorMsg.delete().catch(() => {}), 7000);
    }
  }
};
