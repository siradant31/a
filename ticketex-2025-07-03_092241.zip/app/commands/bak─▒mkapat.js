const fs = require("fs");
const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "bakımkapat",
  description: "Bakım modunu kapatır (sadece sahibi)",

  async run(client, message) {
    if (message.author.id !== message.ownerId) {
      return message.reply("❌ Bu komutu kullanmak için yetkin yok.");
    }

    const bakımVeri = {
      aktif: false,
      sebep: ""
    };
    fs.writeFileSync("./bakim.json", JSON.stringify(bakımVeri, null, 2));

    const embed = new EmbedBuilder()
      .setColor("Green")
      .setTitle("✅ Bakım Modu Devre Dışı")
      .setDescription("Bot artık tüm komutlara açıktır.")
      .setTimestamp();

    message.reply({ embeds: [embed] });
  }
};
