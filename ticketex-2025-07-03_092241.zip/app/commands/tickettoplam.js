const fs = require("fs");
const path = require("path");
const { EmbedBuilder } = require("discord.js");
const { isAdmin } = require("../functions/permissionCheck");

module.exports = {
  name: "tickettoplam",
  description: "🎫 Toplam kaç ticket açıldığını gösterir",

  async run(client, message) {
    if (!(await isAdmin(message.member))) {
      return message.reply("❌ Bu komutu kullanmak için yetkin yok.");
    }

    const userPath = path.join(__dirname, "../veri/ticketKullanicilar.json");
    if (!fs.existsSync(userPath)) return message.reply("📁 Ticket verisi yok.");

    const users = JSON.parse(fs.readFileSync(userPath, "utf8"));

    const embed = new EmbedBuilder()
      .setTitle("🎫 Toplam Ticket Sayısı")
      .setColor("Blue")
      .setDescription(`📌 Şimdiye kadar açılan ticket sayısı: **${users.length}**`);

    message.channel.send({ embeds: [embed] });
  }
};
