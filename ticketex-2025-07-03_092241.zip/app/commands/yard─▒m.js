const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "yardım",
  description: "📘 Tüm komutları listeler.",

  async run(client, message, args) {
    const embed = new EmbedBuilder()
      .setTitle("📘 Yardım Menüsü")
      .setDescription("Aşağıda botun tüm kullanılabilir komutları kategorilere ayrılarak listelenmiştir:")
      .addFields(
        {
          name: "🎫 Ticket Komutları",
          value: "`?ticketpanel`, `?ticketkur`, `?ticketkilit`, `?ticketlog`, `?ticketistatistik`, `?ticketgünlük`, `?tickettoplam`, `?otocevap`, `?ticketsüre`, `?ticketbilgilendirme`"
        },
        {
          name: "🎉 Çekiliş Komutları",
          value: "`?çekiliş`, `?çekilişliste`, `?çekilişyenile`, `?çekilişiptal`, `?çekilişsil`, `?çekilişbak`, `?çekilişyenikazanan`, `?çekilişkatılanlar`, `?çekilişayar`, `?çekilişdm`, `?çekilişlog`, `?çekilişlogsil`"
        },
        {
          name: "🧹 Temizlik Komutları",
          value: "`?sil <sayı>` – Mesajları topluca siler."
        },
        {
          name: "📊 Genel Bilgi Komutları",
          value: "`?ping`, `?istatistik`, `?yardım`"
        },
        {
          name: "🔧 Yönetici Komutları",
          value: "`?duyuru`, `?dmduyuru`, `?bakım`, `?bakımkapat`"
        }
      )
      .setColor("Blue")
      .setFooter({ text: `${client.user.username} Yardım Sistemi` })
      .setTimestamp();

    message.reply({ embeds: [embed] });
  }
};
