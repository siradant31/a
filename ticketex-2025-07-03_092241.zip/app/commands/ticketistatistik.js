const fs = require("fs");
const path = require("path");
const { EmbedBuilder, PermissionsBitField } = require("discord.js");

module.exports = {
  name: "ticketistatistik",
  description: "📊 Ticket sistemine dair istatistikleri gösterir",
  async run(client, message) {
    const botOwnerId = "1373906120954875964";
    const isOwner = message.author.id === message.guild.ownerId;
    const isBotOwner = message.author.id === botOwnerId;
    const isAdmin = message.member.permissions.has(PermissionsBitField.Flags.Administrator);

    if (!isOwner && !isBotOwner && !isAdmin) {
      return message.reply("❌ Bu komutu kullanmak için yetkin yok.");
    }

    const logPath = path.join(__dirname, "../veri/ticket_log.json");
    const userPath = path.join(__dirname, "../veri/ticketKullanicilar.json");

    const logs = fs.existsSync(logPath) ? JSON.parse(fs.readFileSync(logPath, "utf8")) : [];
    const users = fs.existsSync(userPath) ? JSON.parse(fs.readFileSync(userPath, "utf8")) : [];

    const toplam = logs.length;
    const benzersizKull = new Set(logs.map(log => log.kapatan)).size;

    const embed = new EmbedBuilder()
      .setTitle("📊 Ticket İstatistikleri")
      .setColor("Green")
      .addFields(
        { name: "Toplam Kapatılan Ticket", value: `${toplam}`, inline: true },
        { name: "Farklı Kapatanlar", value: `${benzersizKull}`, inline: true },
        { name: "Toplam Açan Kullanıcı", value: `${users.length}`, inline: true }
      )
      .setTimestamp();

    message.channel.send({ embeds: [embed] });
  }
};
