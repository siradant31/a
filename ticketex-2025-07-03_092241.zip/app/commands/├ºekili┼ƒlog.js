const fs = require("fs");
const path = require("path");
const { EmbedBuilder } = require("discord.js");
const { isAdmin } = require("../functions/permissionCheck");

module.exports = {
  name: "çekilişlog",
  description: "📜 Geçmiş tüm çekilişlerin detaylı logunu gösterir",
  async run(client, message, args) {
    if (!isAdmin(message)) {
      return message.reply("❌ Bu komutu kullanmak için yetkin yok.");
    }

    const dataPath = path.join(__dirname, "../veri/cekilisVeri.json");

    if (!fs.existsSync(dataPath)) {
      return message.reply("📁 Henüz kayıtlı bir çekiliş bulunmuyor.");
    }

    const veriler = JSON.parse(fs.readFileSync(dataPath, "utf8"));

    if (veriler.length === 0) {
      return message.reply("📁 Geçmiş çekiliş kaydı bulunamadı.");
    }

    const embed = new EmbedBuilder()
      .setTitle("📜 Çekiliş Logları")
      .setColor("DarkVividPink")
      .setFooter({ text: `${client.user.username} • Çekiliş Sistemi`, iconURL: client.user.displayAvatarURL() })
      .setTimestamp();

    const liste = veriler
      .slice(-10)
      .reverse()
      .map((cekilis, index) =>
        `\n**${index + 1}. Çekiliş**\n🎁 Ödül: **${cekilis.odul}**\n👑 Kazanan: <@${cekilis.kazanan}> (${cekilis.kazanan})\n📅 Tarih: \`${cekilis.tarih}\``)
      .join("\n");

    embed.setDescription(liste);

    message.channel.send({ embeds: [embed] });
  }
};
