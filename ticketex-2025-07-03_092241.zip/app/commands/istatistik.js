const os = require("os");
const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "istatistik",
  description: "Botun sistem bilgilerini gösterir",
  async run(client, message, args) {
    const uptime = process.uptime();
    const ram = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2);
    const cpuModel = os.cpus()[0].model;

    function formatTime(seconds) {
      const d = Math.floor(seconds / 86400);
      const h = Math.floor((seconds % 86400) / 3600);
      const m = Math.floor((seconds % 3600) / 60);
      const s = Math.floor(seconds % 60);
      return `${d}g ${h}s ${m}d ${s}sn`;
    }

    const embed = new EmbedBuilder()
      .setTitle("📊 Bot İstatistikleri")
      .addFields(
        { name: "🔧 Sunucu Sayısı", value: `${client.guilds.cache.size}`, inline: true },
        { name: "👥 Kullanıcı Sayısı", value: `${client.users.cache.size}`, inline: true },
        { name: "📂 Komut Sayısı", value: `${client.commands.size}`, inline: true },
        { name: "📶 Ping", value: `${client.ws.ping}ms`, inline: true },
        { name: "🧠 RAM Kullanımı", value: `${ram} MB`, inline: true },
        { name: "🖥️ CPU", value: `${cpuModel}`, inline: false },
        { name: "⏱️ Çalışma Süresi", value: `${formatTime(uptime)}`, inline: false },
        { name: "🧪 Node.js", value: `${process.version}`, inline: true },
        { name: "📦 Discord.js", value: `v14`, inline: true }
      )
      .setColor("Blue")
      .setFooter({ text: `${client.user.username} Sistem Bilgisi` })
      .setTimestamp();

    message.reply({ embeds: [embed] });
  }
};