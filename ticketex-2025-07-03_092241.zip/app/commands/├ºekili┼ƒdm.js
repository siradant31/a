const fs = require("fs");
const path = require("path");
const { isAdmin } = require("../functions/permissionCheck");

const ayarPath = path.join(__dirname, "../veri/cekilis_ayar.json");

module.exports = {
  name: "çekilişdm",
  description: "📩 Kazanana otomatik DM gönderimini açar/kapatır.",
  async run(client, message, args) {
    if (!isAdmin(message.member)) {
      return message.reply("❌ Bu komutu sadece **yönetici** yetkisine sahip kişiler kullanabilir.");
    }

    if (!args[0] || !["aç", "kapat"].includes(args[0])) {
      return message.reply("⚠️ Lütfen `aç` veya `kapat` olarak belirtin.\nÖrnek: `,çekilişdm aç`");
    }

    let veri = { cekilisDmAktif: true };
    if (fs.existsSync(ayarPath)) {
      veri = JSON.parse(fs.readFileSync(ayarPath, "utf8"));
    }

    veri.cekilisDmAktif = args[0] === "aç";

    fs.writeFileSync(ayarPath, JSON.stringify(veri, null, 2));
    message.channel.send(`✅ Çekiliş kazanana DM gönderimi başarıyla **${args[0]}ıldı**.`);
  }
};